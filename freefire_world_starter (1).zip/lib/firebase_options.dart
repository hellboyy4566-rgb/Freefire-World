// TODO: run flutterfire configure to generate real options
